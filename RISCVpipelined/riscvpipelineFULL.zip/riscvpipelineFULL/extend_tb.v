module extend_tb();
    reg [31:0] inst;
    reg [1:0] ImmSrc;
    wire [31:0] ImmExt;
    
    extend DUT (
        .inst(inst),
        .ImmSrc(ImmSrc),
        .ImmExt(ImmExt)
    );
    
    initial begin 
        // I-Type
        #10 inst = 32'hF1234567; ImmSrc = 2'b00;
        // S-Type
        #10 inst = 32'hF1234567; ImmSrc = 2'b01;
        // B-Type
        #10 inst = 32'hF1234567; ImmSrc = 2'b10;
        // J-Type
        #10 inst = 32'hF1234567; ImmSrc = 2'b11;
    end
    
    initial begin
        $monitor("%4t | %h | %2b | %h", $time, inst, ImmSrc, ImmExt);
    end

    initial begin
        $dumpfile("extend_tb.vcd");
        $dumpvars(0, extend_tb);
    end
endmodule