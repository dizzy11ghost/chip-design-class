module instruction_memory_tb();
    reg [31:0] A;
    wire [31:0] RD;
	 
    instruction_memory DUT (
        .A(A),
        .RD(RD)
    );
    
    initial begin
        #10 A = 32'b00000000; //primera intsrucción
        #10 A = 32'b00000010; //segunda instrucción
        #10 A = 32'b11111111; //test fuera de rango
    end
    
    initial begin
        $monitor("%4t | %h | %h", $time, A, RD);
    end

    initial begin
        $dumpfile("instruction_memory_tb.vcd");
        $dumpvars(0, instruction_memory_tb);
    end
endmodule