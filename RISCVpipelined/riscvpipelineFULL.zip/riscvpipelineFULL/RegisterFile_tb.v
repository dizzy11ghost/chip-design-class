module RegisterFile_tb;

reg clk, rst, WE3;
reg [4:0] A1, A2, A3;
reg [31:0] WD3;

wire [31:0] RD1, RD2;

RegisterFile dut(
    clk,rst,WE3,
    A1,A2,A3,
    WD3,
    RD1,RD2
);

always #5 clk=~clk;

initial begin
    clk=0; rst=1;
    WE3=0; A1=0; A2=0; A3=0; WD3=0;

    #10 rst=0;
    WE3=1; A3=5'd3; WD3=32'h12345678;

    #10 WE3=0;
    A1=5'd3;
    A2=5'd0;

    #20 $finish;
end

initial begin
        $dumpfile("RegisterFile_tb.vcd");
        $dumpvars(0, RegisterFile_tb);
    end

endmodule