module ALUdecoder_tb();
    reg [1:0] ALUOp;
    reg funct7;
    reg [2:0] funct3;
    wire [2:0] Control;

    ALUdecoder DUT (
        .ALUOp(ALUOp),
        .funct7(funct7),
        .funct3(funct3),
        .Control(Control)
    );
    
    initial begin
        //ADD
        #10 ALUOp = 2'b00; funct7 = 0; funct3 = 3'b000;
        
        //SUB
        #10 ALUOp = 2'b01; funct7 = 0; funct3 = 3'b000;
        
        //OR
        #10 ALUOp = 2'b10; funct3 = 3'b110;  // OR
        
        //AND
        #10 ALUOp = 2'b10; funct3 = 3'b111;  // AND
        
        //default (ADD (000))
        #10 ALUOp = 2'b11;  
    end
    
    initial begin
        $monitor("%4t |    %b   |    %b     |   %b   |     %b", 
                $time, ALUOp, funct7, funct3, Control);
    end

    initial begin
        $dumpfile("ALUdecoder_tb.vcd");
        $dumpvars(0, ALUdecoder_tb);
    end
endmodule