module ALU_tb();
    reg [31:0] A, B;
    reg [2:0] Control;
    wire [31:0] Result;
    wire Zero;
    
    ALU DUT (
        .A(A),
        .B(B),
        .Control(Control),
        .Result(Result),
        .Zero(Zero)
    );
    
    initial begin
        A = 32'h00000001;  //1
        B = 32'h00000002;  //2
        Control = 3'b000;  //ADD
        
        #10 Control = 3'b000; // ADD (1 + 2 = 3)
        #10 Control = 3'b001; // SUB (1 - 2 = -1)
        #10 Control = 3'b010; // AND (1 & 2)
        #10 Control = 3'b011; // OR (1 | 2)
        #10 Control = 3'b100; // XOR (1 ^ 2)
        #10 Control = 3'b110; // Shift left (1 << 2)
        
        //comprobamos el zero;
        #10 A = 32'h00000000;
           B = 32'h00000000;
           Control = 3'b000; 
    end
    
    initial begin
        $monitor("t=%t | Op=%b | A=%h | B=%h -> Result=%h | Zero=%b", 
                 $time, Control, A, B, Result, Zero);
    end

    initial begin
        $dumpfile("alu_tb.vcd");
        $dumpvars(0, ALU_tb);
    end

endmodule