module PipeReg_ID_EX_tb;

reg clk, rst, CLR;
reg RegWriteD, MemWriteD, JumpD, BranchD, ALUSrcD;
reg [1:0] ResultSrcD;
reg [2:0] ALUControlD;
reg [31:0] RD1D, RD2D, PCD, ImmExtD, PCPlus4D;
reg [4:0] Rs1D, Rs2D, RdD;

wire RegWriteE, MemWriteE, JumpE, BranchE, ALUSrcE;
wire [1:0] ResultSrcE;
wire [2:0] ALUControlE;
wire [31:0] RD1E, RD2E, PCE, ImmExtE, PCPlus4E;
wire [4:0] Rs1E, Rs2E, RdE;

PipeReg_ID_EX dut(
    clk,rst,CLR,
    RegWriteD,ResultSrcD,MemWriteD,JumpD,BranchD,ALUControlD,ALUSrcD,
    RD1D,RD2D,PCD,Rs1D,Rs2D,RdD,ImmExtD,PCPlus4D,
    RegWriteE,ResultSrcE,MemWriteE,JumpE,BranchE,ALUControlE,ALUSrcE,
    RD1E,RD2E,PCE,Rs1E,Rs2E,RdE,ImmExtE,PCPlus4E
);

always #5 clk=~clk;

initial begin
    clk=0; rst=1; CLR=0;
    RegWriteD=0; ResultSrcD=0; MemWriteD=0;
    JumpD=0; BranchD=0; ALUControlD=0; ALUSrcD=0;
    RD1D=0; RD2D=0; PCD=0; Rs1D=0; Rs2D=0;
    RdD=0; ImmExtD=0; PCPlus4D=0;

    #10 rst=0;
    RegWriteD=1; ResultSrcD=2'b01; MemWriteD=1;
    JumpD=1; BranchD=1; ALUControlD=3'b101; ALUSrcD=1;
    RD1D=1; RD2D=2; PCD=3; Rs1D=4; Rs2D=5;
    RdD=6; ImmExtD=7; PCPlus4D=8;

    #10 CLR=1;
    #10 CLR=0;
    #10 $finish;
end

initial begin
        $dumpfile("PipeReg_ID_EX_tb.vcd");
        $dumpvars(0, PipeReg_ID_EX_tb);
    end

endmodule