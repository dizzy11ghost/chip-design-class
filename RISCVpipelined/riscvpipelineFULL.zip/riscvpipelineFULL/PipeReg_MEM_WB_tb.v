module PipeReg_MEM_WB_tb;

reg clk, rst, RegWriteM;
reg [1:0] ResultSrcM;
reg [31:0] ALUResultM, ReadDataM, PCPlus4M;
reg [4:0] RdM;

wire RegWriteW;
wire [1:0] ResultSrcW;
wire [31:0] ALUResultW, ReadDataW, PCPlus4W;
wire [4:0] RdW;

PipeReg_MEM_WB dut(
    clk,rst,
    RegWriteM,ResultSrcM,
    ALUResultM,ReadDataM,RdM,PCPlus4M,
    RegWriteW,ResultSrcW,
    ALUResultW,ReadDataW,RdW,PCPlus4W
);

always #5 clk=~clk;

initial begin
    clk=0; rst=1;
    RegWriteM=0; ResultSrcM=0;
    ALUResultM=0; ReadDataM=0;
    RdM=0; PCPlus4M=0;

    #10 rst=0;
    RegWriteM=1; ResultSrcM=2'b01;
    ALUResultM=32'hAAAAAAAA;
    ReadDataM=32'h55555555;
    RdM=5'd10;
    PCPlus4M=32'd100;

    #20 $finish;
end

initial begin
        $dumpfile("PipeReg_MEM_WB_tb.vcd");
        $dumpvars(0, PipeReg_MEM_WB_tb);
    end

endmodule