module PipeReg_IF_ID_tb;

reg clk, rst, EN, CLR;
reg [31:0] InstrF, PCF, PCPlus4F;

wire [31:0] InstrD, PCD, PCPlus4D;

PipeReg_IF_ID dut(
    clk,rst,EN,CLR,
    InstrF,PCF,PCPlus4F,
    InstrD,PCD,PCPlus4D
);

always #5 clk=~clk;

initial begin
    clk=0; rst=1; EN=0; CLR=0;
    InstrF=0; PCF=0; PCPlus4F=0;

    #10 rst=0; EN=1;
    InstrF=32'h12345678;
    PCF=32'd20;
    PCPlus4F=32'd24;

    #10 CLR=1;
    #10 $finish;
end

initial begin
        $dumpfile("PipeReg_IF_ID_tb.vcd");
        $dumpvars(0, PipeReg_IF_ID_tb);
    end

endmodule