module mainDecoder_tb;

reg [6:0] opcode;
wire RegWrite, ALUSrc, MemWrite, Branch, Jump;
wire [1:0] ImmSrc, ResultSrc, ALUOp;

mainDecoder dut(
    .opcode(opcode),
    .RegWrite(RegWrite),
    .ImmSrc(ImmSrc),
    .ALUSrc(ALUSrc),
    .MemWrite(MemWrite),
    .ResultSrc(ResultSrc),
    .Branch(Branch),
    .ALUOp(ALUOp),
    .Jump(Jump)
);

initial begin
    opcode = 7'd3; // L-type
    #10 opcode = 7'd35; // I-type
    #10 opcode = 7'd51; // S-type
    #10 opcode = 7'd99; // B-type
    #10 opcode = 7'd19; // J-type
    #10 opcode = 7'd111; // U-type
    #10 opcode = 7'd0; // R-type
    #10 $finish;
end

initial begin
        $dumpfile("mainDecoder_tb.vcd");
        $dumpvars(0, mainDecoder_tb);
    end

endmodule