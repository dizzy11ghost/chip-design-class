module HazardUnit_tb;

reg [4:0] Rs1D, Rs2D, Rs1E, Rs2E, RdE, RdM, RdW;
reg RegWriteM, RegWriteW, ResultSrcE0, PCSrcE;
wire StallF, StallD, FlushD, FlushE;
wire [1:0] ForwardAE, ForwardBE;

HazardUnit dut(
    .Rs1D(Rs1D),
    .Rs2D(Rs2D),
    .Rs1E(Rs1E),
    .Rs2E(Rs2E),
    .RdE(RdE),
    .RdM(RdM),
    .RdW(RdW),
    .RegWriteM(RegWriteM),
    .RegWriteW(RegWriteW),
    .ResultSrcE0(ResultSrcE0),
    .PCSrcE(PCSrcE),
    .StallF(StallF),
    .StallD(StallD),
    .FlushD(FlushD),
    .FlushE(FlushE),
    .ForwardAE(ForwardAE),
    .ForwardBE(ForwardBE)
);

initial begin
    Rs1D=0; Rs2D=0; Rs1E=0; Rs2E=0; RdE=0; RdM=0; RdW=0; //inicializamos todo en 0
    RegWriteM=0; RegWriteW=0; ResultSrcE0=0; PCSrcE=0; 

    #10 Rs1E=5; RdM=5; RegWriteM=1; // ForwardAE debería ser 10 (2'b10)
    #10 Rs1E=0; RdM=0; RegWriteM=0; Rs1E=3; RdW=3; RegWriteW=1; // ForwardAE debería ser 01 (2'b01)
    #10 Rs2E=7; RdM=7; RegWriteM=1; // ForwardBE debería ser 10 (2'b10)
    #10 Rs2E=0; RdM=0; RegWriteM=0; Rs2E=4; RdW=4; RegWriteW=1; // ForwardBE debería ser 01 (2'b01)
    #10 Rs1D=2; RdE=2; ResultSrcE0=1; // StallF y StallD deberían ser 1, FlushE debería ser 1
    #10 Rs1D=0; RdE=0; ResultSrcE0=0; PCSrcE=1; // FlushD y FlushE deberían ser 1, StallF y StallD deberían ser 0
    #10 $finish;
end

initial begin
        $dumpfile("HazardUnit_tb.vcd");
        $dumpvars(0, HazardUnit_tb);
    end

endmodule