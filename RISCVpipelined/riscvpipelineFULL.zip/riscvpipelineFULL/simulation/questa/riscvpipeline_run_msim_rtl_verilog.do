transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/top.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/sumador.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/RegisterFile.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/ProgramCounter.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/PipeReg_MEM_WB.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/PipeReg_IF_ID.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/PipeReg_ID_EX.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/PipeReg_EX_MEM.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/multiplexor.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/memory_RAM.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/mainDecoder.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/HazardUnit.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/extend.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/BranchComparator.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/ALUdecoder.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/ALU.v}
vlog  -work work +incdir+C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip {C:/Users/sophi/Desktop/TEC-VERSE/4semIRS/disenochip/instruction_memory.v}

