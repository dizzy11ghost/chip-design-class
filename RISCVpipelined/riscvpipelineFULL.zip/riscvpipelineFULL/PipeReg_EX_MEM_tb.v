module PipeReg_EX_MEM_tb;

reg clk, rst;
reg RegWriteE, MemWriteE;
reg [1:0] ResultSrcE;
reg [31:0] ALUResultE, WriteDataE, PCPlus4E;
reg [4:0] RdE;

wire RegWriteM, MemWriteM;
wire [1:0] ResultSrcM;
wire [31:0] ALUResultM, WriteDataM, PCPlus4M;
wire [4:0] RdM;

PipeReg_EX_MEM dut(
    clk, rst,
    RegWriteE, ResultSrcE, MemWriteE,
    ALUResultE, WriteDataE, RdE, PCPlus4E,
    RegWriteM, ResultSrcM, MemWriteM,
    ALUResultM, WriteDataM, RdM, PCPlus4M
);

always #5 clk = ~clk;

initial begin
    clk=0; rst=1;
    RegWriteE=0; ResultSrcE=0; MemWriteE=0;
    ALUResultE=0; WriteDataE=0; RdE=0; PCPlus4E=0;

    #10 rst=0;
    RegWriteE=1; ResultSrcE=2'b01; MemWriteE=1;
    ALUResultE=32'h12345678; WriteDataE=32'hABCDEF00;
    RdE=5'd5; PCPlus4E=32'd100;

    #20 $finish;
end

initial begin
        $dumpfile("PipeReg_EX_MEM_tb.vcd");
        $dumpvars(0, PipeReg_EX_MEM_tb);
    end

endmodule