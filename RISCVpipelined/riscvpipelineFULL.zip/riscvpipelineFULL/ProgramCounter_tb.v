module ProgramCounter_tb;

reg clk, rst, EN;
reg [31:0] PCNext;
wire [31:0] PC;

ProgramCounter dut(
    clk,rst,EN,PCNext,PC
);

always #5 clk=~clk;

initial begin
    clk=0; rst=1; EN=0; PCNext=0;

    #10 rst=0; EN=1; PCNext=32'd4;
    #10 PCNext=32'd8;
    #10 EN=0; PCNext=32'd12;
    #10 $finish;
end
initial begin
        $dumpfile("ProgramCounter_tb.vcd");
        $dumpvars(0, ProgramCounter_tb);
    end

endmodule